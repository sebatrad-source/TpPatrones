package AbstractFactory;

public interface MetodoEnvio {
    void enviar();
}
