package AbstractFactory;

public interface AbstractFactory {
    InterfazUI crearUI();
    MetodoEnvio CrearEnvio();
}
