package AbstractFactory;

public interface InterfazUI {
    void mostrarUI();
}
