package MethodFactory;

public interface Libro {
    String getTipo();
}
